import threading
import os
from flask import Flask, render_template, send_from_directory, abort
from config import Config
from logger import logger
from msf_console_manager import MSFConsoleManager
from api import api_bp, init_api
from socket_events import socketio, init_socket, monitor_changes

DOWNLOAD_FOLDER = os.path.join(os.getcwd(), 'downloads')
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    socketio.init_app(app, async_mode='threading')
    return app

if __name__ == '__main__':
    app = create_app()

    # msfconsole yöneticisini başlat
    msf = MSFConsoleManager()
    try:
        msf.start()
        logger.info("msfconsole başlatıldı.")
    except Exception as e:
        logger.error(f"msfconsole başlatılamadı: {e}")
        exit(1)

    # API ve SocketIO'ya msf nesnesini aktar
    init_api(msf)
    init_socket(msf)

    # Blueprint'i kaydet
    app.register_blueprint(api_bp, url_prefix='/api')

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/download/<filename>')
    def download_file(filename):
        # Güvenlik: sadece payload_ ile başlayan dosyalar
        if not filename.startswith('payload_'):
            abort(404)
        file_path = os.path.join('/tmp', filename)
        if os.path.exists(file_path):
            return send_from_directory('/tmp', filename, as_attachment=True)
        abort(404)

    # Oturum/iş takip thread'ini başlat
    monitor_thread = threading.Thread(target=monitor_changes, daemon=True)
    monitor_thread.start()

    # Flask uygulamasını çalıştır
    socketio.run(app, host='0.0.0.0', port=5000, debug=False, allow_unsafe_werkzeug=True)