from flask_socketio import SocketIO, emit
from logger import logger
import threading

socketio = SocketIO()
msf = None

def init_socket(msf_instance):
    global msf
    msf = msf_instance

@socketio.on('start_console')
def handle_start_console(data=None):
    if not msf or not msf.process:
        return
    def stream_output():
        while msf and msf.process and msf.process.poll() is None:
            chunk = msf.get_latest_output()
            if chunk:
                socketio.emit('console_output', {'output': chunk})
            socketio.sleep(0.3)
    threading.Thread(target=stream_output, daemon=True).start()
    emit('console_created', {'message': 'Konsol başlatıldı, canlı çıktı akıyor.'})

@socketio.on('stop_console')
def handle_stop_console(data=None):
    pass

@socketio.on('console_input')
def handle_console_input(data=None):
    if not data or not msf:
        return
    command = data.get('command')
    if not command:
        return
    try:
        output = msf._execute_command(command)
        socketio.emit('console_output', {'output': output + '\n'})
    except Exception as e:
        socketio.emit('console_output', {'output': f'Hata: {e}\n'})

def monitor_changes():
    last_sessions = {}
    last_jobs = {}
    while True:
        socketio.sleep(5)
        try:
            if msf and msf.process and msf.process.poll() is None:
                sessions = msf.get_sessions()
                if sessions != last_sessions:
                    socketio.emit('sessions_update', sessions)
                    last_sessions = sessions
                jobs = msf.get_jobs()
                if jobs != last_jobs:
                    socketio.emit('jobs_update', jobs)
                    last_jobs = jobs
        except Exception as e:
            logger.error(f"Monitor hatası: {e}")