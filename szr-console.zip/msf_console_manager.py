import subprocess
import threading
import queue
import time
import re
import os
import tempfile
from logger import logger
from config import Config

class MSFConsoleManager:
    def __init__(self):
        self.process = None
        self.lock = threading.Lock()
        self.output_queue = queue.Queue()
        self._stop_reading = False
        self._reader_thread = None
        self.prompt_marker = "SZR_PROMPT_END"
        self._initialized = False

    def start(self):
        try:
            self.process = subprocess.Popen(
                [Config.MSF_CONSOLE_PATH, '-q'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            time.sleep(1)
            self._send_raw('echo ' + self.prompt_marker)
            self._wait_for_marker(timeout=10)
            logger.info("msfconsole başlatıldı ve hazır.")
            self._initialized = True
            self._start_reader_thread()
        except Exception as e:
            logger.error(f"msfconsole başlatılamadı: {e}")
            raise

    def _start_reader_thread(self):
        self._stop_reading = False
        self._reader_thread = threading.Thread(target=self._read_output_loop, daemon=True)
        self._reader_thread.start()

    def _read_output_loop(self):
        while not self._stop_reading and self.process and self.process.poll() is None:
            try:
                line = self.process.stdout.readline()
                if line:
                    self.output_queue.put(line)
                else:
                    break
            except Exception as e:
                logger.error(f"Okuma hatası: {e}")
                break

    def get_latest_output(self):
        chunks = []
        while not self.output_queue.empty():
            chunks.append(self.output_queue.get_nowait())
        return ''.join(chunks)

    def stop(self):
        self._stop_reading = True
        if self.process:
            try:
                self.process.stdin.write('exit -y\n')
                self.process.stdin.flush()
                self.process.wait(timeout=5)
            except:
                self.process.kill()
            logger.info("msfconsole durduruldu.")

    def _send_raw(self, cmd):
        with self.lock:
            if not self.process or self.process.poll() is not None:
                raise Exception("msfconsole süreci çalışmıyor")
            self.process.stdin.write(cmd + '\n')
            self.process.stdin.flush()

    def _wait_for_marker(self, timeout=30):
        output = ""
        start = time.time()
        while time.time() - start < timeout:
            line = self.process.stdout.readline()
            if not line:
                break
            if self.prompt_marker in line:
                output += line.replace(self.prompt_marker, '')
                break
            output += line
        return output

    def _execute_command(self, cmd):
        with self.lock:
            self.process.stdin.write(cmd + '\n')
            self.process.stdin.flush()
            self.process.stdin.write('echo ' + self.prompt_marker + '\n')
            self.process.stdin.flush()
            return self._wait_for_marker()

    # ---------- Modül İşlemleri ----------
    def get_modules(self):
        modules = {}
        for mtype, cmd in [('exploit', 'show exploits'),
                           ('auxiliary', 'show auxiliary'),
                           ('post', 'show post'),
                           ('payload', 'show payloads')]:
            out = self._execute_command(cmd)
            modules[mtype] = self._parse_module_list(out)
        return modules

    def _parse_module_list(self, output):
        result = {}
        for line in output.splitlines():
            m = re.match(r'\s*(\S+)\s{2,}(.+)', line)
            if m:
                name = m.group(1)
                desc = m.group(2).strip()
                result[name] = desc
        return result

    def search_modules(self, keyword):
        results = []
        keyword_lower = keyword.lower()
        categories = {
            'exploit': 'show exploits',
            'auxiliary': 'show auxiliary',
            'post': 'show post',
            'payload': 'show payloads',
            'encoder': 'show encoders',
            'nop': 'show nops'
        }
        for mod_type, cmd in categories.items():
            out = self._execute_command(cmd)
            parsed = self._parse_module_list(out)
            for name, desc in parsed.items():
                if keyword_lower in name.lower() or keyword_lower in desc.lower():
                    results.append({
                        'type': mod_type,
                        'name': name,
                        'description': desc
                    })
        return results

    def module_info(self, module_type, module_name):
        self._execute_command(f'use {module_type}/{module_name}')
        return self._execute_command('info')

    def execute_module(self, module_type, module_name, options):
        self._execute_command(f'use {module_type}/{module_name}')
        for key, val in options.items():
            self._execute_command(f'set {key} {val}')
        out = self._execute_command('run -j')
        job_id = None
        m = re.search(r'Backgrounding job (\d+)', out)
        if m:
            job_id = int(m.group(1))
        return {'job_id': job_id, 'output': out}

    # ---------- Oturum / İş ----------
    def get_sessions(self):
        out = self._execute_command('sessions -l')
        return self._parse_sessions(out)

    def _parse_sessions(self, output):
        sessions = {}
        for line in output.splitlines():
            parts = line.strip().split()
            if len(parts) >= 5 and parts[0].isdigit():
                sid = parts[0]
                stype = parts[1]
                target = ''
                if '->' in line:
                    target = line.split('->')[1].strip().split()[0]
                sessions[sid] = {'type': stype, 'target_host': target, 'info': line.strip()}
        return sessions

    def get_jobs(self):
        out = self._execute_command('jobs -l')
        return self._parse_jobs(out)

    def _parse_jobs(self, output):
        jobs = {}
        for line in output.splitlines():
            if re.match(r'\s*\d+', line):
                parts = line.strip().split()
                if parts[0].isdigit():
                    jid = parts[0]
                    name = parts[1] if len(parts) > 1 else ''
                    jobs[jid] = {'name': name, 'info': line.strip()}
        return jobs

    def run_single_session_cmd(self, session_id, command):
        return self._execute_command(f'sessions -c "{command}" -i {session_id}')

    # ---------- Payload Üretim ----------
    def get_payloads(self):
        out = self._execute_command('show payloads')
        return self._parse_module_list(out)

    def generate_payload(self, payload_name, options, output_format='raw'):
        try:
            self._execute_command(f'use payload/{payload_name}')
            for key, val in options.items():
                self._execute_command(f'set {key} {val}')
            ext_map = {
                'exe': '.exe', 'exe-small': '.exe', 'exe-only': '.exe',
                'elf': '.elf', 'macho': '.macho',
                'raw': '.bin', 'python': '.py', 'bash': '.sh', 'perl': '.pl', 'c': '.c',
                'powershell': '.ps1', 'vba': '.vba', 'dll': '.dll'
            }
            suffix = ext_map.get(output_format, '.out')
            tmp_fd, tmp_path = tempfile.mkstemp(suffix=suffix, prefix='payload_', dir='/tmp')
            os.close(tmp_fd)
            cmd = f'generate -f {output_format} -o {tmp_path}'
            self._execute_command(cmd)
            if os.path.exists(tmp_path) and os.path.getsize(tmp_path) > 0:
                return {'status': True, 'file_path': tmp_path, 'download_url': f'/download/{os.path.basename(tmp_path)}'}
            else:
                return {'status': False, 'error': 'Payload dosyası oluşturulamadı.'}
        except Exception as e:
            return {'status': False, 'error': str(e)}