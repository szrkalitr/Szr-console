import sqlite3
import threading
from logger import logger

class Database:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, db_name='szr_console.db'):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance.db_name = db_name
                    cls._instance._init_db()
        return cls._instance

    def _init_db(self):
        with self.get_connection() as conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                module_type TEXT,
                module_name TEXT,
                options TEXT,
                result_summary TEXT
            )''')
            conn.execute('''CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )''')
        logger.info("Veritabanı başlatıldı.")

    def get_connection(self):
        return sqlite3.connect(self.db_name)

    def execute_query(self, query, params=None):
        with self.get_connection() as conn:
            cursor = conn.execute(query, params or ())
            conn.commit()
            return cursor

    def fetch_all(self, query, params=None):
        with self.get_connection() as conn:
            cursor = conn.execute(query, params or ())
            return cursor.fetchall()

    def add_history(self, module_type, module_name, options, result_summary):
        self.execute_query(
            "INSERT INTO history (module_type, module_name, options, result_summary) VALUES (?,?,?,?)",
            (module_type, module_name, options, result_summary)
        )

    def get_history(self, limit=50):
        rows = self.fetch_all(
            "SELECT id, timestamp, module_type, module_name, options, result_summary FROM history ORDER BY id DESC LIMIT ?",
            (limit,)
        )
        return [
            {"id": r[0], "timestamp": r[1], "module_type": r[2], "module_name": r[3], "options": r[4], "result": r[5]}
            for r in rows
        ]