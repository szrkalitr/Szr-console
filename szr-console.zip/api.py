from flask import Blueprint, request
from utils import standard_response, validate_required
from logger import logger

api_bp = Blueprint('api', __name__)
msf = None

def init_api(msf_instance):
    global msf
    msf = msf_instance

@api_bp.route('/status')
def status():
    if msf and msf.process and msf.process.poll() is None:
        return standard_response(True, data={"version": "msfconsole (direct)"})
    return standard_response(False, error="msfconsole bağlı değil")

@api_bp.route('/modules')
def modules():
    try:
        mods = msf.get_modules()
        return standard_response(True, data=mods)
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/modules/search')
def modules_search():
    q = request.args.get('q', '')
    if len(q) < 2:
        return standard_response(False, error="En az 2 karakter gerekli")
    try:
        res = msf.search_modules(q)
        return standard_response(True, data=res)
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/module/<module_type>/<path:module_name>')
def module_info(module_type, module_name):
    try:
        info = msf.module_info(module_type, module_name)
        return standard_response(True, data={"info": info})
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/module/execute', methods=['POST'])
def module_execute():
    data = request.json
    if not data:
        return standard_response(False, error="JSON veri gerekli", status_code=400)
    mtype = data.get('type')
    mname = data.get('name')
    options = data.get('options', {})
    valid, msg = validate_required({'type': mtype, 'name': mname})
    if not valid:
        return standard_response(False, error=msg, status_code=400)
    try:
        result = msf.execute_module(mtype, mname, options)
        return standard_response(True, data=result)
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/sessions')
def sessions():
    try:
        sess = msf.get_sessions()
        return standard_response(True, data=sess)
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/jobs')
def jobs():
    try:
        jobs = msf.get_jobs()
        return standard_response(True, data=jobs)
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/session/<int:session_id>/command', methods=['POST'])
def session_command(session_id):
    data = request.json
    if not data or 'command' not in data:
        return standard_response(False, error="command zorunlu", status_code=400)
    try:
        out = msf.run_single_session_cmd(session_id, data['command'])
        return standard_response(True, data={"output": out})
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/topology')
def topology():
    try:
        sess = msf.get_sessions()
        nodes = [{"id": "attacker", "label": "Attacker", "group": "attacker"}]
        edges = []
        for sid, s in sess.items():
            host = s.get('target_host', 'unknown')
            nodes.append({"id": host, "label": f"{host}\n({s['type']})", "group": s['type']})
            edges.append({"from": "attacker", "to": host, "label": f"Session {sid}"})
        return standard_response(True, data={"nodes": nodes, "edges": edges})
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/history')
def history():
    return standard_response(True, data=[])

# ---------- Yeni Payload Endpointleri ----------
@api_bp.route('/payloads')
def payloads():
    try:
        payloads = msf.get_payloads()
        return standard_response(True, data=payloads)
    except Exception as e:
        return standard_response(False, error=str(e))

@api_bp.route('/payload/generate', methods=['POST'])
def payload_generate():
    data = request.json
    payload_name = data.get('payload')
    options = data.get('options', {})
    output_format = data.get('format', 'raw')
    if not payload_name:
        return standard_response(False, error="payload seçilmedi", status_code=400)
    result = msf.generate_payload(payload_name, options, output_format)
    if result['status']:
        return standard_response(True, data={'download_url': result['download_url']})
    else:
        return standard_response(False, error=result['error'])