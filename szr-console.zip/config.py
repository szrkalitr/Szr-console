import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    MSF_CONSOLE_PATH = os.getenv('MSF_CONSOLE_PATH', 'msfconsole')
    SECRET_KEY = os.getenv('SECRET_KEY', 'default-secret')