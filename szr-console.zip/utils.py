from flask import jsonify

def standard_response(success, data=None, error=None, status_code=200):
    response = {"status": "success" if success else "error"}
    if data is not None:
        response["data"] = data
    if error:
        response["error"] = error
    return jsonify(response), status_code

def validate_required(fields):
    for name, value in fields.items():
        if not value:
            return False, f"{name} alanı zorunludur."
    return True, None