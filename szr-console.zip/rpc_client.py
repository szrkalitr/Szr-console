import time
import threading
import requests
from logger import logger
from config import Config

class MetasploitRPC:
    def __init__(self):
        self.token = None
        self.session = requests.Session()
        self.lock = threading.Lock()
        self.last_error = ""
        self.connected = False
        self._stop_reconnect = False
        self._reconnect_thread = None

    def _call(self, method, *params):
        headers = {}
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": int(time.time() * 1000)
        }
        try:
            resp = self.session.post(Config.MSF_RPC_URL, json=payload, headers=headers, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            if 'error' in data:
                self.last_error = data['error'].get('message', 'Unknown error')
                return None
            return data.get('result')
        except requests.exceptions.RequestException as e:
            self.last_error = str(e)
            logger.error(f"RPC çağrı hatası: {e}")
            return None

    def login(self):
        with self.lock:
            result = self._call('auth.login', Config.MSF_RPC_USER, Config.MSF_RPC_PASS)
            if result and 'token' in result:
                self.token = result['token']
                self.connected = True
                logger.info("Metasploit RPC giriş başarılı.")
                return True
            logger.error(f"RPC giriş başarısız: {self.last_error}")
            return False

    def logout(self):
        with self.lock:
            if self.token:
                self._call('auth.logout', self.token)
                self.token = None
                self.connected = False

    def _auto_reconnect(self):
        while not self._stop_reconnect:
            if not self.connected:
                logger.info("RPC bağlantısı koptu, yeniden bağlanılıyor...")
                self.login()
            time.sleep(5)

    def start_reconnect_daemon(self):
        if self._reconnect_thread is None:
            self._reconnect_thread = threading.Thread(target=self._auto_reconnect, daemon=True)
            self._reconnect_thread.start()

    def stop_reconnect(self):
        self._stop_reconnect = True

    # ---------- Modül ----------
    def module_list(self, module_type='exploit'):
        with self.lock:
            return self._call('module.list', module_type)

    def module_info(self, module_type, module_name):
        with self.lock:
            return self._call('module.info', module_type, module_name)

    def module_execute(self, module_type, module_name, options):
        with self.lock:
            return self._call('module.execute', module_type, module_name, options)

    # ---------- Oturum ----------
    def session_list(self):
        with self.lock:
            return self._call('session.list')

    # ---------- İşler ----------
    def job_list(self):
        with self.lock:
            return self._call('job.list')

    def job_stop(self, job_id):
        with self.lock:
            return self._call('job.stop', job_id)

    # ---------- Konsol ----------
    def console_create(self):
        with self.lock:
            return self._call('console.create')

    def console_read(self, console_id):
        with self.lock:
            return self._call('console.read', console_id)

    def console_write(self, console_id, command):
        with self.lock:
            return self._call('console.write', console_id, command)

    def console_destroy(self, console_id):
        with self.lock:
            return self._call('console.destroy', console_id)

    def core_version(self):
        with self.lock:
            return self._call('core.version')

# Tekil nesne
rpc_client = MetasploitRPC()